import { img2, img3, img4, img5, img6, img7, img8, img9 } from "../../common/imagepath";

export default {
    Data: [
        {
          Id: 1,
          Transaction: 137370531,
          Invoice: "#4987",
          Name: "John Smith ",
          Phone:"+1 843-443-3282",
          Img:img2,
          Amount: "$1,54,220",
          date: "19 Dec 2022, 06:12 PM",
          Payment: "Cash"
        },
        {
          Id: 2,
          Transaction: 137370532,
          Invoice: "#4988",
          Name: "Johnny",
          Phone:"+1 917-409-0861",
          Img: img3,
          Amount: "$2,54,220",
          date: "19 Dec 2022, 06:12 PM",
          Payment: "Cheque"
        },
        {
          Id: 3,
          Transaction: 137370533,
          Invoice: "#4989",
          Name: "Robert",
          Phone:"+1 956-623-2880",
          Img: img4,
          Amount: "$3,54,220",
          date: "19 Dec 2022, 06:12 PM",
          Payment: "Cash"
        },
        {
          Id: 4,
          Transaction: 137370534,
          Invoice: "#4990",
          Name: "Sharonda",
          Phone:"+1 707-439-1732",
          Img: img5,
          Amount: "$4,54,220",
          date: "19 Dec 2022, 06:12 PM",
          Payment: "Cheque"
        },
        {
          Id: 5,
          Transaction: 137370535,
          Invoice: "#4991",
          Name: "Randall",
          Phone:"+1 559-741-9672",
          Img: img7,
          Amount: "$5,54,220",
          date: "19 Dec 2022, 06:12 PM",
          Payment: "Cheque"
        },
        {
          Id: 6,
          Transaction: 137370536,
          Invoice: "#4992",
          Name: "Pricilla",
          Phone:"+1 989-438-3131",
          Img: img6,
          Amount: "$4,54,220",
          date: "19 Dec 2022, 06:12 PM",
          Payment: "Cheque"
        },
        {
          Id: 7,
          Transaction: 137370532,
          Invoice: "#4988",
          Name: "John Smith",
          Phone:"+1 843-443-3282",
          Img: img7,
          Amount: "$1,54,220",
          date: "19 Dec 2022, 06:12 PM",
          Payment: "Cash"
        },
        {
          Id: 8,
          Transaction: 137370533,
          Invoice: "#4989",
          Name: "Johnny",
          Phone:"+1 917-409-0861",
          Img: img8,
          Amount: "$2,54,220",
          date: "19 Dec 2022, 06:12 PM",
          Payment: "Cheque"
        },
        {
          Id: 9,
          Transaction: 1373705334,
          Invoice: "#4990",
          Name: "Robert",
          Phone:"+1 956-623-2880",
          Img: img9,
          Amount: "$3,54,220",
          date: "19 Dec 2022, 06:12 PM",
          Payment: "Cash"
        }
       ]
}