import {
  img1,
  img11,
  img14,
  img15,
  img16,
  img17,
  img18,
  img19,
  img2,
  img4,
  img5,
  img6,
  img7,
  img8,
  img9,
} from "../../common/imagepath";

export default {
  Data: [
    {
      Id: 4,
      Ticket: "#4990",
      Subject: "Management",
      Assigned: "Sharonda",
      AssignedDate: "27 Feb 2022",
      CreatedOn: "28 Feb 2022, 6:12PM",
      DueDate: "29 Mar 2023",
      Img: img8,
      img: img17,
      Assignee: "Randall",
      Phone: "+1 843-443-5298",
      LastReply: "25 Jan 2023",
      Priority: "Medium",
      Status: "Closed",
      Action: "",
    },
  ],
};
