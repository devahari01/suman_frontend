import { img16 } from "../../common/imagepath";

export default {
  Data: [
    {
      id: 3,
      Invoice: "#4989",
      Name: "Robert",
      email: " robert@example.com",
      img: img16,
      Amount: "$1,54,220",
      Created: "25 Feb 2023",
      Cancelled: "18 Mar 2022",
      Status: "Cancelled",
      Action: "",
    },
  ],
};
