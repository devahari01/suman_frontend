export default {
    Data: [
        {
          Id: 1,
          Pages: "About Us",
          PagesSlug: "about-us",
          Status: "",
          Action: ""
        },
        {
          Id: 2,
          Pages: "Cookie Policy",
          PagesSlug: "cookie-policy",
          Status: "",
          Action: ""
        },
        {
          Id: 3,
          Pages: "FAQ",
          PagesSlug: "faq",
          Status: "",
          Action: ""
        },
        {
          Id: 4,
          Pages: "Helps",
          PagesSlug: "helps",
          Status: "",
          Action: ""
        },
        {
          Id: 5,
          Pages: "Home",
          PagesSlug: "home",
          Status: "",
          Action: ""
        },
        {
          Id: 6,
          Pages: "Privacy Policy",
          PagesSlug: "privacy-policy",
          Status: "",
          Action: ""
        }
       ]
}