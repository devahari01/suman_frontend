import { img1, img2, img3, img4, img5, img6, img7 } from "../../common/imagepath";

export default {
    Data: [
        {
          Id: 1,
          img:img2,
          Name: "John Smith",
          email: "john@example.com",
          Rating: "",
          Content: "Lorem ipsum dolor sit amet, consectetur",
          Created: "19 Dec 2022, 06:12 PM",
          Status: "Active",
          Actions: ""
        },
        {
          Id: 2,
          img:img3,
          Name: "Johnny",
          email: " johnny@example.com",
          Rating: "",
          Content: "Lorem ipsum dolor sit amet, consectetur",
          Created: "15 Dec 2022, 06:12 PM",
          Status: "Active",
          Actions: ""
        },
        {
          Id: 3,
          img:img4,
          Name: "Robert",
          email: " robert@example.com",
          Rating: "",
          Content: "Lorem ipsum dolor sit amet, consectetur",
          Created: "04 Dec 2022, 12:38 PM",
          Status: "Deactive",
          Actions: ""
        },
        {
          Id: 4,
          img:img5,
          Name: "Sharonda",
          email: " sharon@example.com",
          Rating: "",
          Content: "Lorem ipsum dolor sit amet, consectetur",
          Created: "14 Dec 2022, 12:38 PM",
          Status: "Active",
          Actions: ""
        },
        {
          Id: 5,
          img:img6,
          Name: "Pricilla",
          email: "pricilla@example.com",
          Rating: "",
          Content: "Lorem ipsum dolor sit amet, consectetur",
          Created: "12 Dec 2022, 12:38 PM",
          Status: "Active",
          Actions: ""
        },
        {
          Id: 6,
          img:img7,
          Name: "Randall ",
          email: "randall@example.com",
          Rating: "",
          Content: "Lorem ipsum dolor sit amet, consectetur",
          Created: "04 Dec 2022, 12:38 PM",
          Status: "Deactive",
          Actions: ""
        }
    ]
}