import React from "react";
import EditPurchaseReturn from "./EditpurchaseReturn";
import { EditPurchaseReturnComponentController } from "./EditpurchaseReturn.control";

const EditPurchasereturnComponent = () => {
  return (
    <>
      <EditPurchaseReturnComponentController>
        <EditPurchaseReturn />
      </EditPurchaseReturnComponentController>
    </>
  );
};

export default EditPurchasereturnComponent;
