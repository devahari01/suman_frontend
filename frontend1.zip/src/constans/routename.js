

export const dashboard = `/index`;
export const login = `/index`;
export const register = `/register`;
export const products = `/products-list`;