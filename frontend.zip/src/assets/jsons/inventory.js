export default {
    Data: [
        {
          Id: 1,
          Item: "Lorem ipsum dolor sit",
          Code: "P125389",
          Units: "Inches",
          Quantity: 2,
          Sales: "$253.00",
          Purchase: "$248.00",
          Action: ""
        },
        {
          Id: 2,
          Item: "Lorem ipsum dolor sit",
          Code: "P125390",
          Units: "Pieces",
          Quantity: 4,
          Sales: "$360.00",
          Purchase: "$350.00",
          Action: ""
        },
        {
          Id: 3,
          Item: "Sed ut perspiciatis unde",
          Code: "P125391",
          Units: "Inches",
          Quantity: 7,
          Sales: "$724.00",
          Purchase: "$700.00",
          Action: ""
        },
        {
          Id: 4,
          Item: "Nemo enim ipsam",
          Code: "P125392",
          Units: "Box",
          Quantity: 3,
          Sales: "$210.00",
          Purchase: "$200.00",
          Action:""
        },
        {
          Id: 5,
          Item: "Neque porro quisquam",
          Code: "P125393",
          Units: "Kilograms",
          Quantity: 1,
          Sales: "$155.00",
          Purchase: "$150.00",
          Action: ""
        },
        {
          Id: 6,
          Item: "Nemo enim ipsam",
          Code: "P125389",
          Units: "Inches",
          Quantity: 2,
          Sales: "$253.00",
          Purchase: "$248.00",
          Action: ""
        },
        {
          Id: 7,
          Item: "Lorem ipsum dolor sit",
          Code: "P125390",
          Units: "Inches",
          Quantity: 2,
          Sales: "$253.00",
          Purchase: "$248.00",
          Action: ""
        },
        {
          Id: 8,
          Item: "Lorem ipsum dolor sit",
          Code: "P125391",
          Units: "Pieces",
          Quantity: 4,
          Sales: "$360.00",
          Purchase: "$350.00",
          Action: ""
        },
        {
          Id: 9,
          Item: "Sed ut perspiciatis unde",
          Code: "P125392",
          Units: "Inches",
          Quantity: 7,
          Sales: "$724.00",
          Purchase: "$700.00",
          Action: ""
        }
       ]
}