export default {
    Data: [
        {
          Id: 1,
          Unit: "Kilogram",
          Short: "kg",
          Action: ""
        },
        {
          Id: 2,
          Unit: "Gram",
          Short: "g",
          Action: ""
        },
        {
          Id: 3,
          Unit: "Liter",
          Short: "l",
          Action: ""
        },
        {
          Id: 4,
          Unit: "Milliliter",
          Short: "ml",
          Action: ""
        },
        {
          Id: 5,
          Unit: "Pack",
          Short: "pk",
          Action: ""
        },
        {
          Id: 6,
          Unit: "Piece",
          Short: "pc",
          Action: ""
        },
        {
          Id: 7,
          Unit: "Kilogram",
          Short: "kg",
          Action: ""
        },
        {
          Id: 8,
          Unit: "Gram",
          Short: "g",
          Action: ""
        },
        {
          Id: 9,
          Unit: "Liter",
          Short: "l",
          Action: ""
        }
       ]
}