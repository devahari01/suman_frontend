import { UserSign } from "../../common/imagepath";

export default {
  Data: [
    {
      Id: 1,
      SignatureName: "Allen",
      Img: UserSign,
      Status: "",
      Action: "",
    },
    {
      Id: 2,
      SignatureName: "Raymond",
      Img: UserSign,
      Status: "",
      Action: "",
    },
    {
      Id: 3,
      SignatureName: "Ralph",
      Img: UserSign,
      Status: "",
      Action: "",
    },
    {
      Id: 4,
      SignatureName: "Ruth",
      Img: UserSign,
      Status: "",
      Action: "",
    },
    {
      Id: 5,
      SignatureName: "Steven",
      Img: UserSign,
      Status: "",
      Action: "",
    },
    {
      Id: 6,
      SignatureName: "Earnes",
      Img: UserSign,
      Status: "",
      Action: "",
    },
  ],
};
