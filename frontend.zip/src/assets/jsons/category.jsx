import { Category1, Category2, Category3, Category4, Category5, Category6 } from "../../common/imagepath";

export default {
    Data : [
        {
          Id: 1,
          Category: "Advertising",
          Img: Category1,
          Total: 60,
          Action: ""
        },
        {
          Id: 2,
          Category: "Food",
          Img: Category2,
          Total: 55,
          Action: ""
        },
        {
          Id: 3,
          Category: "Marketing",
          Img: Category3,
          Total: 70,
          Action: ""
        },
        {
          Id: 4,
          Category: "Repairs",
          Img: Category4,
          Total: 82,
          Action: ""
        },
        {
          Id: 5,
          Category: "Software",
          Img: Category5,
          Total: 26,
          Action: ""
        },
        {
          Id: 6,
          Category: "Stationary",
          Img: Category6,
          Total: 60,
          Action: ""
        },
        {
          Id: 7,
          Category: "Advertising",
          Img: Category1,
          Total: 60,
          Action: ""
        },
        {
          Id: 8,
          Category: "Food",
          Img: Category2,
          Total: 55,
          Action: ""
        },
        {
          Id: 9,
          Category: "Marketing",
          Img: Category3,
          Total: 70,
          Action: ""
        }
    ]
}