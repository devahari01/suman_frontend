import { img1, img2, img3, img4, img5, img6, img7 } from "../../common/imagepath";

export default {
  Data: [
    {
      id: 1,
      img:img2,
      Name: "John Smith",
      email: "john@example.com",
      Phone: "+1 989-438-3131",
      Balance: "$4,220",
      Invoice: 2,
      Created: "19 Dec 2022, 06:12 PM",
      Status: "Deactive",
      Action:""
    },
    {
      id: 2,
      img:img3,
      Name: "Johnny",
      email: " johnny@example.com",
      Phone: "+1 843-443-3282",
      Balance: "$1,862",
      Invoice: 1,
      Created: "15 Dec 2022, 06:12 PM",
      Status: "Deactive",
      Action:""
    },
    {
      id: 3,
      img:img4,
      Name: "Robert",
      email: " robert@example.com",
      Phone: "+1 917-409-0861",
      Balance: "$2,789",
      Invoice: 3,
      Created: "04 Dec 2022, 12:38 PM",
      Status: "Deactive",
      Action:""
    },
    {
      id: 4,
      img:img5,
      Name: "Sharonda",
      email: " sharon@example.com",
      Phone: "+1 956-623-2880",
      Balance: "$6,789",
      Invoice: 6,
      Created: "14 Dec 2022, 12:38 PM",
      Status: "Deactive",
      Action:""
    },
    {
      id: 5,
      img:img6,
      Name: "Pricilla",
      email: "pricilla@example.com",
      Phone: "+1 956-613-2880",
      Balance: "$1,789",
      Invoice: 4,
      Created: "12 Dec 2022, 12:38 PM",
      Status: "Deactive",
      Action:""
    },
    {
      id: 6,
      img:img7,
      Name: "Randall ",
      email: "randall@example.com",
      Phone: "+1 117-409-0861",
      Balance: "$1,789",
      Invoice: 1,
      Created: "04 Dec 2022, 12:38 PM",
      Status: "Deactive",
      Action:""
    },
    {
      id: 7,
      img:img2,
      Name: "John Smith ",
      email: "john@example.com",
      Phone: "+1 989-438-3131",
      Balance: "$4,220",
      Invoice: 2,
      Created: "19 Dec 2022, 06:12 PM",
      Status: "Deactive",
      Action:""
    },
    {
      id: 8,
      img:img4,
      Name: "Johnny ",
      email: "johnny@example.com",
      Phone: "+1 843-443-3282",
      Balance: "$1,862",
      Invoice: 1,
      Created: "15 Dec 2022, 06:12 PM",
      Status: "Deactive",
      Action:""
    },
    {
      id: 9,
      img:img3,
      Name: "Robert",
      email: " robert@example.com",
      Phone: "+1 917-409-0861",
      Balance: "$2,789",
      Invoice: 3,
      Created: "04 Dec 2022, 12:38 PM",
      Status: "Deactive",
      Action:""
    },
  ],
};
