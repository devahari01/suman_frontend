import { img2, img3, img4, img5, img6, img7, img8, img9 } from "../../common/imagepath";

export default {
    Data: [
        {
          id: 1,
          Name: "John Smith",
          Email:"john@example.com",
          Img:img2,
          Phone: "+1 989-438-3131",
          Role: "$4,220",
          Activity: "10 mins ago",
          Created: "19 Dec 2022, 06:12 PM",
          Status: "Active",
          Actions: ""
        },
        {
          id: 2,
          Name: "Johnny",
          Email:"johnny@example.com",
          Img: img3,
          Phone: "+1 843-443-3282",
          Role: "$1,862",
          Activity: "Online",
          Created: "15 Dec 2022, 06:12 PM",
          Status: "Active",
          Actions: ""
        },
        {
          id: 3,
          Name: "Robert",
          Email:"robert@example.com",
          Img: img4,
          Phone: "+1 917-409-0861",
          Role: "$2,789",
          Activity: "Online",
          Created: "04 Dec 2022, 12:38 PM",
          Status: "Restricted",
          Actions: ""
        },
        {
          id: 4,
          Name: "Sharonda",
          Email:"sharon@example.com",
          Img: img5,
          Phone: "+1 956-623-2880",
          Role: "$6,789",
          Activity: "1 hour ago",
          Created: "14 Dec 2022, 12:38 PM",
          Status: "Active",
          Actions: ""
        },
        {
          id: 5,
          Name: "Pricilla",
          Email:"pricilla@example.com",
          Img: img7,
          Phone: "+1 956-613-2880",
          Role: "$1,789",
          Activity: "Online",
          Created: "12 Dec 2022, 12:38 PM",
          Status: "Active",
          Actions: ""
        },
        {
          id: 6,
          Name: "Randall",
          Email:"randall@example.com",
          Img: img6,
          Phone: "+1 117-409-0861",
          Role: "$1,789",
          Activity: "2 days ago",
          Created: "04 Dec 2022, 12:38 PM",
          Status: "Restricted",
          Actions: ""
        },
        {
          id: 7,
          Name: "John Smith",
          Email:"john@example.com",
          Img: img7,
          Phone: "+1 989-438-3131",
          Role: "$4,220",
          Activity: "10 mins ago",
          Created: "19 Dec 2022, 06:12 PM",
          Status: "Active",
          Actions: ""
        },
        {
          id: 8,
          Name: "Johnny",
          Email:"johnny@example.com",
          Img: img8,
          Phone: "+1 843-443-3282",
          Role: "$1,862",
          Activity: "Online",
          Created: "15 Dec 2022, 06:12 PM",
          Status: "Active",
          Actions: ""
        },
        {
          id: 9,
          Name: "Robert",
          Email:"robert@example.com",
          Img: img9,
          Phone: "+1 917-409-0861",
          Role: "$2,789",
          Activity: "Online",
          Created: "04 Dec 2022, 12:38 PM",
          Status: "Restricted",
          Actions: ""
        }
       ]
}