import { img19 } from "../../common/imagepath";

export default {
  Data: [
    {
      id: 6,
      Invoice: "#4992",
      Category: "Stationary",
      Created: "16 Nov 2022",
      Name: "Randall ",
      email: "+1 989-438-3131",
      img: img19,
      Total: "$5,54,220",
      Paid: "$6,50,000",
      Payment: "Cash",
      Balance: "$4,220",
      Due: "25 Feb 2023",
      Status: "Refunded",
      Action: "",
    },
  ],
};
