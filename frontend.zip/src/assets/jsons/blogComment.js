import { img2, img3, img4, img5, img6, img7 } from "../../common/imagepath";

export default {
    Data: [
        {
          Id: 1,
          Name: "John Smith",
          Img:img2,
          Phone:"+1 843-443-3282",
          Email: "john@example.com",
          Content: "Lorem ipsum dolor sit amet, consectetur",
          Created: "19 Dec 2022, 06:12 PM",
          Actions: ""
        },
        {
          Id: 2,
          Name: "Johnny",
          Img: img3,
          Phone: "+1 917-409-0861",
          Email: "johnny@example.com",
          Content: "Excepteur sint occaecat cupidatat non",
          Created: "15 Dec 2022, 04:35 PM",
          Actions: ""
        },
        {
          Id: 3,
          Name: "Robert",
          Img: img4,
          Phone: "+1 956-623-2880",
          Email: "robert@example.com",
          Content: "Duis aute irure dolor in reprehenderit",
          Created: "04 Dec 2022, 12:38 PM",
          Actions: ""
        },
        {
          Id: 4,
          Name: "Sharonda",
          Img: img5,
          Phone: "+1 707-439-1732",
          Email: "sharon@example.com",
          Content: "Excepteur sint occaecat cupidatat non",
          Created: "14 Dec 2022, 12:38 PM",
          Actions: ""
        },
        {
          Id: 5,
          Name: "Randall",
          Img: img7,
          Phone: "+1 559-741-9672",
          Email: "pricilla@example.com",
          Content: "Sed ut perspiciatis unde omnis iste natus",
          Created: "12 Dec 2022, 12:38 PM",
          Actions: ""
        },
        {
          Id: 6,
          Name: "Pricilla",
          Img: img6,
          Phone: "+1 989-438-3131",
          Email: "randall@example.com",
          Content: "Neque porro quisquam est, qui dolorem ipsum",
          Created: "04 Dec 2022, 12:38 PM",
          Actions: ""
        },
        {
          Id: 7,
          Name: "John Smith",
          Img:img2,
          Phone:"+1 843-443-3282",
          Email: "john@example.com",
          Content: "Lorem ipsum dolor sit amet, consectetur",
          Created: "19 Dec 2022, 06:12 PM",
          Actions: ""
        },
        {
          Id: 8,
          Name: "Johnny",
          Img: img3,
          Phone: "+1 917-409-0861",
          Email: "johnny@example.com",
          Content: "Excepteur sint occaecat cupidatat non",
          Created: "15 Dec 2022, 04:35 PM",
          Actions: ""
        },
        {
          Id: 9,
          Name: "Robert",
          Img: img4,
          Phone: "+1 956-623-2880",
          Email: "robert@example.com",
          Content: "Duis aute irure dolor in reprehenderit",
          Created: "04 Dec 2022, 12:38 PM",
          Actions: ""
        }
       ]
}