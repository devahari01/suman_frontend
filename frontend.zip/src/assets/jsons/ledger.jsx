import { img1, img2, img3, img4, img5, img6, img7, img8, img9 } from "../../common/imagepath";

export default {
  Data: [
    {
      id: 1,
      img:img2,
      Name: "John Smith",
      Phone: "+1 843-443-3282",
      Reference:"#25689825",
      Created: "19 Dec 2022, 06:12 PM",
      Mode:"Credit",
      Action:""
    },
    {
      id: 2,
      img:img3,
      Name: "Johnny",
      Phone: "+1 917-409-0861",
      Reference:"#25689826",
      Created: "15 Dec 2022, 06:12 PM",
      Mode:"Debit",
      Action:""
    },
    {
      id: 3,
      img:img7,
      Name: "Johnny",
      Phone: "+1 917-409-0861",
      Reference:"#25689827",
      Created: "04 Dec 2022, 12:38 PM",
      Mode:"Credit",
      Action:""
    },
    {
      id: 4,
      img:img9,
      Name: "Pricilla Smith",
      Phone: "+1 956-623-2880",
      Reference:"#25689828",
      Created: "14 Dec 2022, 12:38 PM",
      Mode:"Credit",
      Action:""
    },
    {
      id: 5,
      img:img6,
      Name: "Pricilla",
      Phone: "+1 956-613-2880",
      Reference:"#25689829",
      Created: "12 Dec 2022, 12:38 PM",
      Mode:"Debit",
      Action:""
    },
    {
      id: 6,
      img:img7,
      Name: "Randall ",
      Phone: "+1 117-409-0861",
      Reference:"#25689830",
      Created: "04 Dec 2022, 12:38 PM",
      Mode:"Credit",
      Action:""
    },
    {
      id: 7,
      img:img8,
      Name: "Robert",
      Phone: "+1 989-438-3131",
      Reference:"#25689831",
      Created: "19 Dec 2022, 06:12 PM",
      Mode:"Debit",
      Action:""
    },
    {
      id: 8,
      img:img4,
      Name: "Robert",
      Phone: "+1 843-443-3282",
      Reference:"#25689832",
      Created: "19 Dec 2022, 06:12 PM",
      Mode:"Credit",
      Action:""
    },
    {
      id: 9,
      img:img5,
      Name: "Sharonda",
      Phone: "+1 917-409-0861",
      Reference:"#25689833",
      Created: "04 Dec 2022, 12:38 PM",
      Mode:"Debit",
      Action:""
    },
  ],
};
